<?php

	$db=mysqli_connect("localhost","root","","lms2");  
					/* server name, username, passwor, database name */

?>